declare const console: Console;
